<!DOCTYPE html>
<html lang="en">
<head>
    <title>Document</title>
    <link rel="stylesheet" type="text/css" media="screen" href="css/index-desktop.css"/>
    <link rel="stylesheet" type="text/css" media="screen and (max-width:1020px)" href="css/index-mobile.css"/>
</head>
<body>
        <div class="navbar">
                <div class="item-navbar">
                    <a href="wewe.php"><img src="images/logo1.jpg" width="20%"></a>
                </div>
                <div class="item-navbar">
                    <ul>
                        <li><a href="kucing.php">Tentang Kucing</a></li>
                        <li><a href="form.php">Bisnis</a></li>
                        <li><a href="index.php">Data Pembeli Kucing</a></li>
                        <li><a href="about.php">About</a></li>
                    </ul>
                </div>
            </div>
        <div class="footer">Rifqi Iqbal Afandi</div>
        </div>
</body>
</html>