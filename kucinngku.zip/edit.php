<?php
    include "koneksi.php";
    $no = $_GET['no'];
    $qe = mysqli_query($koneksi, "SELECT * FROM tbkucing WHERE no='$no'");
    $data = mysqli_fetch_array($qe);
 ?>
<!DOCTYPE html>
<html>
<head>
    <title>Form Pembelian</title>
</head>
<body>
    <form method="post">
        <input type="text" name="nama" value="<?php echo $data['nama'] ?>">
        <br>
        <textarea name="alamat" >value="<?php echo $data['alamat'] ?>"</textarea>
        <br>
        <input type="text" name="telepon" value="<?php echo $data['telepon'] ?>">
        <br>
        <input type="text" name="ras" value="<?php echo $data['ras'] ?>">
        <br>
        <input type="text" name="warna" value="<?php echo $data['warna'] ?>">
        <br>
        <input type="text" name="usia" value="<?php echo $data['usia'] ?>">
        <br>
        <input type="submit" name="edit" value="Edit">
    </form>
    <?php
        if (isset($_POST['edit'])) {
            $nama = $_POST['nama'];
            $alamat = $_POST['alamat'];
            $telepon = $_POST['telepon'];
            $ras = $_POST['ras'];
            $warna = $_POST['warna'];
            $usia = $_POST['usia'];
            $tambah = mysqli_query($koneksi, "UPDATE tbkucing SET nama='$nama', alamat='$alamat'
            , telepon='$telepon', ras='$ras', warna='$warna', usia='$usia' WHERE no='$no'");
            if ($tambah) {
                ?>
                <script type="text/javascript">
                    alert('Berhasil mengedit data !!');
                    document.location.href="index.php";
                </script>
                <?php
            }
            else{
                echo "Gagal mengedit data !!";
            }
        }
     ?>
</body>
</html>