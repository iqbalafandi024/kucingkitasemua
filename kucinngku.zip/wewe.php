<!DOCTYPE html>
<html>
<head>
    <title>Welcome to Kucing Kita Semua</title>
    <link rel="stylesheet" type="text/css" media="screen" href="css/index-desktop.css"/>
    <link rel="stylesheet" type="text/css" media="screen and (max-width:1020px)" href="css/index-mobile.css"/>
</head>
<body>

</form>
    <div class="container">
        <div class="header">
            <div class="navbar">
                <div class="item-navbar">
                    <a href="wewe.php"><img src="images/logo.jpg" width="40%"></a>
                </div>
                <div class="item-navbar">
                    <ul>
                        <li><a href="kucing.php">Tentang Kucing</a></li>
                        <li><a href="form.php">Bisnis</a></li>
                    
                        <li><a href="index.php">Data Pembelian Kucing</a></li>
                        <li><a href="about.php">About</a></li>
                    </ul>
                </div>
            </div>
            <div class="photo"></div>            
        </div>
        <div class="about">
            <div class="tengah">  
                <div class="item-about">
                    <a href="kucing.php"><img src="images/scottish1.jpg"></a>
                    <h3>Scotttish Fold</h3>
                    <p><i>Scottish Fold</i> - Kucing telinga lipat skotlandia adalah salah satu ras kucing alami yang berasal dari Skotlandia. Ciri khas dan keunikannya adalah terdapat pada telingnya yang melipat, sehingga ras ini disebut dengan kucing berwajah burung hantu atau kucing coupari.</p>
                </div>
                <div class="item-about">
                    <a href="kucing.php"><img src="images/persian1.jpg"></a>
                    <h3>Persian Cat</h3>
                    <p><i>Persian Cat</i> - Kucing persia adalah ras kucing domestik berbulu panjang dengan karakter wajah bulat dan moncong pendek. Namanya mengacu pada Persia, nama lama Iran, di mana kucing serupa ditemukan. Sejak akhir abad 19, kucing jenis ini dikembangkan di Britania Raya dan Amerika Serikat.</p>
                </div>
                <div class="item-about">
                    <a href="kucing.php"><img src="images/anggora3.jpg"></a>
                    <h3>Turkish Anggora</h3>
                    <p><i>Turkish Anggora</i> - Anggora turki adalah salah satu ras kucing domestik alami tertua. Ras ini berasal dari Ankara, Turki. Kucing ini sangat populer dan terkenal di Indonesia. Secara sederhana, ras kucing ini juga dikenal sebagai anggora atau kucing ankara. </p>
                </div>
            </div>
        </div>
        
        <div class="footer">Rifqi Iqbal Afandi</div>
    </div>

</body>
</html>