<!DOCTYPE html>
<html lang="en">
<head>
    <title>Tentang Kucing</title>
    <link rel="stylesheet" type="text/css" media="screen" href="css/index-desktop.css"/>
    <link rel="stylesheet" type="text/css" media="screen and (max-width:1020px)" href="css/index-mobile.css"/>
</head>
<body>
        <div class="navbar">
                <div class="item-navbar">
                    <a href="wewe.php"><img src="images/logo.jpg" width="40%"></a>
                </div>
                <div class="item-navbar">
                    <ul>
                        <li><a href="kucing.php">Tentang Kucing</a></li>
                        <li><a href="form.php">Bisnis</a></li>
                        <li><a href="index.php">Data Pembelian Kucing</a></li>
                        <li><a href="about.php">About</a></li>
                    </ul>
                </div>
            </div>
        <div class="about">
            <div class="tengah">  
                <div class="item-about">
                    <img src="images/scottish1.jpg">
                    <h3>Scotttish Fold</h3>
                    <p><i>Scottish Fold</i> - Kucing telinga lipat skotlandia adalah salah satu ras kucing alami yang berasal dari Skotlandia. Ciri khas dan keunikannya adalah terdapat pada telingnya yang melipat, sehingga ras ini disebut dengan kucing berwajah burung hantu atau kucing coupari.
                    Namun, beberapa kucing telinga lipat skotlandia ada yang lahir dengan telinga yang tidak terlipat, yaitu telinga yang tegak dan meruncing seperti kucing biasanya.
                    Kucing telinga lipat skotlandia adalah kucing berbadan sedang, dengan berat badan jantan sekitar 4-6 kg dan betina sekitar 2.7-4 kg. 
                    Kucing telinga lipat skotlandia memiliki kepala yang bulat, mata yang besar dan bulat, hidung yang pesek, serta leher dan kakinya pendek. Ras ini juga terdapat 2 versi, yaitu bulu panjang dan bulu pendek. 
                    Kucing telinga lipat skotlandia adalah kucing yang rentan terhadap penyakit, seperti penyakit penyakit ginjal polikistik (pertumbuhan kista pada ginjal) dan kardiomiopati (kelainan jantung). Harapan hidup kucing ini dapat mencapai sekitar 15 tahun.</p>
                </div>
                <div class="item-about">
                    <img src="images/persian1.jpg">
                    <h3>Persian Cat</h3>
                    <p><i>Persian Cat</i> - Kucing persia adalah ras kucing domestik berbulu panjang dengan karakter wajah bulat dan moncong pendek. 
                    Namanya mengacu pada Persia, nama lama Iran, di mana kucing serupa ditemukan. 
                    Sejak akhir abad 19, kucing jenis ini dikembangkan di Britania Raya dan Amerika Serikat. 
                    Di Britania Raya, ras ini disebut kucing bulu panjang persia, dibagi dalam dua jenis, yaitu chinchilla dengan warna perak cerah dan yang agak gelap. 
                    Seperti halnya dengan ras siam, telah ada upaya oleh beberapa peternak untuk melestarikan ras kucing yang lebih tua, ras tradisional, yang memiliki moncong lebih jelas, yang lebih akrab dengan masyarakat umumnya. 
                    Pembiakan selektif yang dilakukan oleh peternak telah memungkinkan pengembangan berbagai warna bulu, tetapi juga menyebabkan makin datarnya wajah, yang mungkin membawakan sejumlah masalah kesehatan. 
                    Penyakit ginjal polikistik turunan lazim dialami oleh ras ini, yang mempengaruhi hampir separuh populasinya di beberapa negara.</p>
                </div>
                <div class="item-about">
                    <img src="images/anggora3.jpg">
                    <h3>Turkish Anggora</h3>
                    <p><i>Turkish Anggora</i> - Anggora turki adalah salah satu ras kucing domestik alami tertua. Ras ini berasal dari Ankara, Turki. Kucing ini sangat populer dan terkenal di Indonesia. Secara sederhana, ras kucing ini juga dikenal sebagai anggora atau kucing ankara. 
                    Anggora adalah kucing dengan ciri khas berbulu panjang yang indah. Anggora memiliki tubuh yang sedang dengan badan berotot yang panjang, ramping, langsing dan elegan. 
                    Anggora memiliki hidung yang panjang, kepala yang berbentuk segitiga, serta telinga yang panjang, lebar, dan berbentuk segitiga. Kakinya panjang dan tinggi serta ekornya panjang serta mengembang. 
                    Anggora yang paling disukai adalah anggora putih dengan ciri khas warna matanya yang ganjil. 
                    Anggora yang standar memiliki warna solid (polos), seperti warna putih. Badan jantan anggora harus lebih besar dari yang betina. Tubuhnya harus panjang dengan bagian belakang sedikit lebih tinggi daripada bagian depan.</p>
                </div>
            </div>
        </div>
        <div class="footer">Rifqi Iqbal Afandi</div>
        </div>
</body>
</html>