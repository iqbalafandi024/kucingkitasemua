<?php
    include "koneksi.php";
 ?>
<!DOCTYPE html>
<html>
<head>
    <title>Form Pembelian</title>
    <link rel="stylesheet" type="text/css" media="screen" href="css/index-desktop.css"/>
    <link rel="stylesheet" type="text/css" media="screen and (max-width:1020px)" href="css/index-mobile.css"/>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="navbar">
                <div class="item-navbar">
                    <a href="wewe.php"><img src="images/logo.jpg" width="40%"></a>
                </div>
                <div class="item-navbar">
                    <ul>
                        <li><a href="kucing.php">Tentang Kucing</a></li>
                        <li><a href="form.php">Bisnis</a></li>
                    
                        <li><a href="index.php">Data Pembelian Kucing</a></li>
                        <li><a href="about.php">About</a></li>
                    </ul>
                </div>
            </div>
    <div class="textbox">
    <form method="post">
    <center>
        <input type="text" name="nama" placeholder="Nama"><br>
        <br>
        <textarea name="alamat" placeholder="Alamat"></textarea><br>
        <br>
        <input type="text" name="telepon" placeholder="Telepon"><br>
        <br>
        <input type="text" name="ras" placeholder="Pilihan Ras Kucing"><br>
        <br>
        <input type="text" name="warna" placeholder="Warna"><br>
        <br>
        <input type="text" name="usia" placeholder="Usia Dalam Bulan"><br>
        <br>
        <input type="submit" name="simpan" value="Simpan">
    </center>
    </form>
    </div>
    <?php
        if (isset($_POST['simpan'])) {
            $nama = $_POST['nama'];
            $alamat = $_POST['alamat'];
            $telepon = $_POST['telepon'];
            $ras = $_POST['ras'];
            $warna = $_POST['warna'];
            $usia = $_POST['usia'];
            $tambah = mysqli_query($koneksi, "INSERT INTO tbkucing(nama, alamat, telepon, ras, warna, usia) VALUES('$nama', '$alamat', '$telepon', '$ras', '$warna', '$usia')");
            if ($tambah) {
                ?>
                <script type="text/javascript">
                    alert('Berhasil menambahkan data !!');
                    document.location.href="index.php";
                </script>
                <?php
            }
            else{
                echo "Gagal menambahkan data !!";
            }
        }
     ?>
     <div class="footer">Rifqi Iqbal Afandi</div>
    </div>
</body>
</html>