<!DOCTYPE html>
<html lang="en">
<head>
    <title>About</title>
    <link rel="stylesheet" type="text/css" media="screen" href="css/index-desktop.css"/>
    <link rel="stylesheet" type="text/css" media="screen and (max-width:1020px)" href="css/index-mobile.css"/>
</head>
<body>
        <div class="navbar">
                <div class="item-navbar">
                    <a href="wewe.php"><img src="images/logo.jpg" width="40%"></a>
                </div>
                <div class="item-navbar">
                    <ul>
                        <li><a href="kucing.php">Tentang Kucing</a></li>
                        <li><a href="form.php">Bisnis</a></li>
                        <li><a href="index.php">Data Pembelian Kucing</a></li>
                        <li><a href="about.php">About</a></li>
                    </ul>
                </div>
            </div>
        <h3><p align="center">Tentang Penjual</align></h3><br><br>
        <p align="center"></align>
        <div class="footer">Rifqi Iqbal Afandi</div>
        </div>
</body>
</html>