<?php
    include "koneksi.php";
 ?>
<!DOCTYPE html>
<html>
<head>
    <title>Tabel Database</title>
    <link rel="stylesheet" type="text/css" media="screen" href="css/index-desktop.css"/>
    <link rel="stylesheet" type="text/css" media="screen and (max-width:1020px)" href="css/index-mobile.css"/>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="navbar">
                <div class="item-navbar">
                    <a href="wewe.php"><img src="images/logo.jpg" width="40%"></a>
                </div>
                <div class="item-navbar">
                    <ul>
                        <li><a href="kucing.php">Tentang Kucing</a></li>
                        <li><a href="form.php">Bisnis</a></li>
                    
                        <li><a href="index.php">Data Pembelian Kucing</a></li>
                        <li><a href="about.php">About</a></li>
                    </ul>
                </div>
            </div>
    <table width="60%" align="center" border="2">
        <tr>
            <td colspan="8"><h2><center>Tabel Database Pembelian Kucing</center></h2>
            <a href="wewe.php">Back to Home</a>
            <br>
            <a href="form.php">Tambah Data</a>
            </td>
        </tr>
        <tr>
            <th>No.</th>
            <th width="20%">Nama</th>
            <th width="30%">Alamat</th>
            <th width="15%">Telepon</th>
            <th width="30%">Pilihan Ras</th>
            <th>Warna</th>
            <th>Usia</th>
            <th>Opsi</th>
        </tr>
            <?php
                $no = 1;
                $query = mysqli_query($koneksi, "SELECT * FROM tbkucing");
                while($data = mysqli_fetch_array($query)){
             ?>
        <tr>
            <td><?php echo $no++; ?></td>
            <td><?php echo $data['nama']; ?></td>
            <td><?php echo $data['alamat']; ?></td>
            <td><?php echo $data['telepon']; ?></td>
            <td><?php echo $data['ras']; ?></td>
            <td><?php echo $data['warna']; ?></td>
            <td><?php echo $data['usia']; ?></td>
            <td>
                <a onclick="return confirm('Yakin untuk menghapus ?')"
                href="hapus.php?no=<?php echo $data['no']; ?>">Hapus</a>

                <a href="edit.php?no=<?php echo $data['no']; ?>">Edit</a>
            </td>
        </tr>
            <?php } ?>
    </table>
    <div class="footer">Rifqi Iqbal Afandi</div>
    </div>
</body>
</html>